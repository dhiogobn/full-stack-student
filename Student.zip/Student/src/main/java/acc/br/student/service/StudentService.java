package acc.br.student.service;

import acc.br.student.model.Student;
import acc.br.student.repository.StudentRepository;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StudentService {

    private final StudentRepository studentRepository;

    public void create(Student student) {
        studentRepository.save(student);
    }

    public List<Student> findAll() {
        return studentRepository.findAll();
    }

    public Student getStudentById(int id) {
        return studentRepository.findById(id).get();
    }

    public Student update(int id, Student newStudent) {
        Student student = getStudentById(id);
        student.setAge(newStudent.getAge());
        student.setName(newStudent.getName());
        student.setEmail(newStudent.getEmail());
        return studentRepository.save(student);
    }

    public void deleteById(int id) {
        studentRepository.deleteById(id);
    }

}
